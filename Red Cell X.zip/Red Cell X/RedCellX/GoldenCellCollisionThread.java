package RedCellX;

import java.util.concurrent.atomic.*;
import java.awt.Rectangle;

public class GoldenCellCollisionThread extends Thread {

    private int ballX;
    private int ballY;
    private int ballDiameter;
    private AtomicBoolean collisionResult;
    private Rectangle goldenCellBounds;
    private Object lock;

    public GoldenCellCollisionThread(AtomicBoolean collisionResult, int ballX, int ballY, int ballDiameter, Rectangle goldenCellBounds) {
        
        this.collisionResult = collisionResult;
        this.ballX = ballX;
        this.ballY = ballY;
        this.ballDiameter = ballDiameter;
        this.goldenCellBounds = goldenCellBounds;
        this.lock = new Object();

    }

    public GoldenCellCollisionThread(Object lock) {
        this.lock = lock;
    }

    @Override
    public void run() {
        synchronized(lock) {

            Rectangle ballBounds = new Rectangle(ballX, ballY, ballDiameter, ballDiameter);
            if (ballBounds.intersects(goldenCellBounds)) {
                collisionResult.set(true);
            }
            
        }
    }
        
}