package RedCellX;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Backstory implements ActionListener{

    private JFrame frame;
    private JPanel oldPanel;
    private JPanel panel;
    private JLabel title;
    private JLabel story; 

    private JButton gameButton;
    private RedBloodCellGame redBloodCellGame;
    private String filePath;
    private String storyStored;
    private String[] storyLines;
    private Timer storyTimer;
    private int i = 1;
    private JButton returnButton;

    private Main main;
    
    public Backstory(JFrame frame, Main main) {

        this.frame = frame;
        this.main = main;
        oldPanel = new JPanel();
        panel = new JPanel(new BorderLayout());
        title = new JLabel("Backstory");
        gameButton = new JButton("Start Game");
        returnButton = new JButton("Return");
        story = new JLabel("");
        storyTimer = new Timer(3000, this);

        redBloodCellGame = new RedBloodCellGame(frame, panel);
        
        gameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                redBloodCellGame.startGame(panel);

            }
        });

        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                main.closePanel(frame, panel);

            }
        });

    }

    public void openBackstory(JFrame frame, JPanel oldPanel) {

        this.frame = frame;
        this.oldPanel = oldPanel;
        
        closePanel();
        openPanel();

    }

    public void closePanel() {

        frame.remove(oldPanel);
        frame.revalidate();

    }

    public void openPanel() {

        fillStory();
        fillPanel();
        frame.add(panel);
        frame.revalidate();

    }

    private void fillStory() {

        Dimension dimension = new Dimension((frame.getWidth()), (frame.getHeight()/3));
        story.setPreferredSize(dimension);

        StringBuilder content = new StringBuilder();
        filePath = "Backstory.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String line = "";     

            while((line = br.readLine()) != null) {
            
                content.append(line).append("\n");

            }
            
            storyStored = content.toString();

            story.setText("<html><div style='text-align: justify;'>" + storyStored + "</div></html>");

        } catch (IOException e) {
            // Handle file reading errors
            e.printStackTrace();
        }

        
    }

    public void actionPerformed(ActionEvent e) { 
        
        if (e.getSource() == storyTimer) {

            while (i < 5) {

                story.setText(storyLines[i]);
                i++;
                frame.revalidate();
                storyTimer.start();

            }
        }
    }

    private void fillPanel() {
        
        panel.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        panel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
  
        panel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(50, 40, 50, 40);
        constraints.anchor = GridBagConstraints.CENTER;

        title.setFont(title.getFont().deriveFont(Font.BOLD, 28f));
        
        int x = 200;
        int y = 50;
        Dimension dimension = new Dimension(x,y);

        constraints.gridx = 4;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        panel.add(title, constraints);
        
        constraints.gridwidth = 5;
        constraints.gridx = 3;
        constraints.gridy = 3;
        Font customFont = new Font("Arial", Font.PLAIN, 16); // Font: Arial, Style: Bold, Size: 24
        story.setFont(customFont);
        panel.add(story, constraints);

        constraints.gridwidth = 1;
        constraints.gridx = 3;
        constraints.gridy = 5;
        gameButton.setPreferredSize(dimension);
        Font buttonFont = new Font("Consolas", Font.PLAIN, 16);
        gameButton.setFont(buttonFont);
        panel.add(gameButton, constraints);

        constraints.gridwidth = 1;
        constraints.gridx = 5;
        constraints.gridy = 5;
        returnButton.setPreferredSize(dimension);
        returnButton.setFont(buttonFont);
        panel.add(returnButton, constraints);

        frame.revalidate();
        frame.repaint();

    }

}