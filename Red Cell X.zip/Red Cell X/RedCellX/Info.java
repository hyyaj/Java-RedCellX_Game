package RedCellX;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class Info {

    private int randomInfo;
    private String filePath;
    private String readString;
    private Random random;

    public Info() {

        random = new Random();

    }

    public String readFile() {

        setFilePath();
        StringBuilder content = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String line;
            // Read each line from the file and append it to the StringBuilder
            while ((line = br.readLine()) != null) {

                content.append(line).append("\n"); // Append a newline character for each line

            }

        } catch (IOException e) {

            // Handle file reading errors
            e.printStackTrace();

        }

        readString = content.toString();
        return readString;

    }

    private void setFilePath() {

        randomInfo = random.nextInt(10);
        switch (randomInfo) {
            case 0:
                filePath = "text1.txt";
                break;
            case 1:
                filePath = "text2.txt";
                break;
            case 2:
                filePath = "text3.txt";
                break;
            case 3:
                filePath = "text4.txt";
                break;
            case 4:
                filePath = "text5.txt";
                break;
            case 5:
                filePath = "text6.txt";
                break;
            case 6:
                filePath = "text7.txt";
                break;
            case 7:
                filePath = "text8.txt";
                break;
            case 8:
                filePath = "text9.txt";
                break;
            case 9:
                filePath = "text10.txt";
                break;
            default:
                filePath = "default.txt";
                break;
        }

    }

}
