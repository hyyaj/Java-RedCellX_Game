package RedCellX;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Settings {

    private JFrame frame;
    private JPanel oldPanel;
    private JPanel panel;
    private JLabel title;

    private Main main;

    private Clip clip;
    private FloatControl gainControl;
    // Create radio buttons for music on and off
    private JRadioButton musicOnButton = new JRadioButton("Music On");
    private JRadioButton musicOffButton = new JRadioButton("Music Off");
    private JButton returnButton = new JButton("Back");
    private boolean music = true;

    private JLabel volumeLabel = new JLabel("Volume: 50");

    // Create a slider for volume control (min: 0, max: 100, initial: 50)
    private JSlider volumeSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
    
    // Create a ButtonGroup to ensure only one radio button is selected at a time
    private ButtonGroup buttonGroup = new ButtonGroup();

    private AudioInputStream audioInputStream;
    private float desiredVolumeInDB;

    private boolean isVisible;
    
    public Settings(Main main) {

        frame = new JFrame();
        oldPanel = new JPanel();
        panel = new JPanel(null);
        title = new JLabel("Settings");

        this.main = main;

        try {
            // Open an audio input stream
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(
                Settings.class.getResource("risk.wav"));

            // Get a clip resource
            clip = AudioSystem.getClip();

            // Open audio clip and load samples from the audio input stream
            clip.open(audioInputStream);
            clip.loop(Clip.LOOP_CONTINUOUSLY);

            // Add a line listener to handle the audio clip events
            clip.addLineListener(new LineListener() {
                @Override
                public void update(LineEvent event) {
                    if (event.getType() == LineEvent.Type.STOP) {

                        clip.close(); // Close the clip after it has finished playing

                    }
                }
            });

            // Start playing the audio clip
            if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {

                gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);

            } 

            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        musicOnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                musicOn();

            }
        });

        musicOffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                musicOff();

            }
        });
        
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                main.closePanel(frame, panel);

            }
        });

        volumeSlider.setMajorTickSpacing(10);
        volumeSlider.setMinorTickSpacing(1);
        volumeSlider.setPaintTicks(true);
        volumeSlider.setPaintLabels(true);

        // Add a change listener to handle volume changes
        volumeSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {

                int volume = volumeSlider.getValue();

                // Update the volume label text
                volumeLabel.setText("Volume: " + volume);
                
                // Handle volume change logic here (e.g., adjust audio volume)
                float volumeValue = volume / 100f;
                desiredVolumeInDB = (float) (20 * Math.log10(volumeValue)); // Update desiredVolumeInDB
                adjustVolume(volumeValue); // Adjust volume using the new volume value
            }
        });

    }

    private void adjustVolume(float volumeValue) {

        if (gainControl != null) {
            float range = gainControl.getMaximum() - gainControl.getMinimum();
            float gain = (volumeValue * range) + gainControl.getMinimum();
            gainControl.setValue(gain);
        }

    }

    private void musicOff() {

        if (clip != null && clip.isRunning()) {
            clip.stop(); // Stop the music playback
        }

    }

    public void musicOn() {

        if (clip != null && !(clip.isRunning())) {
            try {
                // Open an audio input stream
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(
                        Settings.class.getResource("risk.wav"));
    
                // Get a clip resource
                Clip newClip = AudioSystem.getClip();
    
                // Open audio clip and load samples from the audio input stream
                newClip.open(audioInputStream);
                newClip.loop(Clip.LOOP_CONTINUOUSLY);
    
                // Update the gainControl reference to the newClip's control
                if (newClip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    gainControl = (FloatControl) newClip.getControl(FloatControl.Type.MASTER_GAIN);
                } else {
                    gainControl = null; // Handle case where volume control is not supported
                }
    
                // Close the old clip
                if (clip != null) {
                    clip.close();
                }
    
                // Update the clip reference to the newClip
                clip = newClip;
    
                // Start playing the audio clip
                clip.start();
                boolean musicRunning = musicRunning();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public boolean musicRunning() {

        music = !music;
        return music;

    }

    public void openSettings(JFrame frame, JPanel oldPanel) {

        this.frame = frame;
        this.oldPanel = oldPanel;

        Container contentPane = frame.getContentPane();

        Dimension dimension = new Dimension(frame.getWidth(), frame.getHeight());
        panel.setPreferredSize(dimension);

        int x = frame.getWidth()/2;
        int y = frame.getHeight()/2;
        panel.setBounds(x,y, frame.getWidth(), frame.getHeight());

        closePanel();
        openPanel(); 
     
        frame.revalidate();
    
    }

    void closePanel() {

        frame.remove(oldPanel);
        frame.getContentPane().removeAll();
        frame.revalidate();

    }

    private void openPanel() {
        panel.setLayout(new GridBagLayout());
        
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(5, 5, 5, 5);
        constraints.anchor = GridBagConstraints.CENTER;
        
        int x = frame.getWidth() / 2;
        int y = 100;
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        title.setFont(title.getFont().deriveFont(Font.BOLD, 36f));
        panel.add(title, constraints);
        
        x = frame.getWidth() / 4;
        y = 200;
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        musicOnButton.setPreferredSize(new Dimension(180, 40));
        panel.add(musicOnButton, constraints);
        
        constraints.gridx = 1;
        musicOffButton.setPreferredSize(new Dimension(180, 40));
        panel.add(musicOffButton, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        returnButton.setPreferredSize(new Dimension(180, 40));
        panel.add(returnButton, constraints);
        
        x = frame.getWidth() / 2;
        y = 200;
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        volumeLabel.setFont(volumeLabel.getFont().deriveFont(24f));
        panel.add(volumeLabel, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 2;
        volumeSlider.setPreferredSize(new Dimension(400, 40));
        panel.add(volumeSlider, constraints);
        
        buttonGroup.add(musicOnButton);
        buttonGroup.add(musicOffButton);
        
        frame.add(panel);
        frame.revalidate();

    }

}

