package RedCellX;

import java.awt.Rectangle;
import java.util.concurrent.atomic.*;

public class PlatformCollisionThread extends Thread {
    
    private int ballX;
    private int ballY;
    private int ballDiameter;
    private int[] xValues = new int[10];
    private int[] yValues = new int[10];
    private int[] widthValues = new int[10];
    private int greenPlatformHeight;
    private AtomicBoolean collisionResult;
    private AtomicInteger platformY;
    private final Object lock;


    public PlatformCollisionThread(AtomicInteger platformY, AtomicBoolean collisionResult, int ballX, int ballY, int ballDiameter, int[] xValues, int[] yValues, int[] widthValues, int greenPlatformHeight) {

        this.platformY = platformY;
        this.collisionResult = collisionResult;
        this.ballX = ballX;
        this.ballY = ballY;
        this.ballDiameter = ballDiameter;
        this.xValues = xValues;
        this.yValues = yValues;
        this.widthValues = widthValues;
        this.greenPlatformHeight = greenPlatformHeight;
        this.lock = new Object();

    }

    public PlatformCollisionThread(Object lock) {

        this.lock = lock;

    }

    @Override
    public void run() {

        /* Perform collision detection here
        Update game state based on collision results
        Checks if the ball is coming in contact with any of the paltforms, returns true if 
        it finds it comes in contact. Initialization of the variables passed by the parameters, 
        which includes the position and size info of the balls
        creating a rectangle hitbox for the ball*/

        synchronized (lock) {
            Rectangle ballBounds = new Rectangle(ballX, ballY, ballDiameter, ballDiameter);
            for (int i=0; i<10; i++) {
                
                /*Check with every platform on screen if the hitboxes collide with that of the
                 ball. If they do intersect then true is returned*/
                Rectangle rectBounds = new Rectangle(xValues[i], yValues[i], widthValues[i], greenPlatformHeight);
                if (ballBounds.intersects(rectBounds)) {

                    collisionResult.set(true);
                    platformY.set(yValues[i]);

                }
            }
        }
    }
}