package RedCellX;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    private JFrame frame;
    private JPanel mainPanel;
    private JLabel titleLabel;
    private JButton startButton;
    private JButton settingsButton;
    private JButton exitButton;
    private Settings settings;
    private Backstory backstory;
    private GameOverScreen gameOver;
    private GameWinnerScreen gameWinner;
    private QuizUI quizUI;
    private JPanel oldPanel;

    public Main() {
        
        frame = new JFrame("Red Cell X");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        settings = new Settings(this);
        backstory = new Backstory(frame, this);
        quizUI = new QuizUI();
        gameWinner = new GameWinnerScreen(frame, mainPanel);
        gameOver = new GameOverScreen(frame, mainPanel);

        titleLabel = new JLabel("Red Cell X");
        Font font = new Font("Arial", Font.BOLD, 28);
        titleLabel.setFont(font);

        mainPanel = new JPanel();
        startButton = new JButton("Start Game");
        settingsButton = new JButton("Settings");
        exitButton = new JButton("Quit Game");

        fillMainPanel();
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.setVisible(true);

        if ((settings.musicRunning())) {
            settings.musicOn();
        }

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {

                    System.exit(0); // Terminate the application
                    
                }
            }
        });

        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                settings.openSettings(frame, mainPanel);

            }
        });

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                backstory.openBackstory(frame, mainPanel);

            }
        });

    }

    public void closePanel(JFrame frame, JPanel oldPanel) {

        this.oldPanel = oldPanel;
        this.frame = frame;
        oldPanel.removeAll();
        frame.remove(oldPanel);
        fillMainPanel();
        frame.add(mainPanel);
        frame.revalidate();
        frame.repaint();

    }

    private void fillMainPanel() {
        
        mainPanel.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        mainPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
  
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 100, 150, 100);
        constraints.anchor = GridBagConstraints.CENTER;

        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 28f));
        
        int x = 200;
        int y = 50;
        Dimension dimension = new Dimension(x,y);

        constraints.gridx = 3;
        constraints.gridy = 1;
        constraints.gridwidth = 3;
        mainPanel.add(titleLabel, constraints);

        constraints.gridwidth = 1;
        constraints.gridx = 2;
        constraints.gridy = 6;
        startButton.setPreferredSize(dimension);
        mainPanel.add(startButton, constraints);

        constraints.gridx = 4;
        constraints.gridy = 6;
        settingsButton.setPreferredSize(dimension);
        mainPanel.add(settingsButton, constraints);

        constraints.gridx = 3;
        constraints.gridy = 8;
        exitButton.setPreferredSize(dimension);
        mainPanel.add(exitButton, constraints);

    }

    public Settings getSettings() {

        return settings;

    }


    public Backstory getBackstory() {

        return backstory;

    }

    public GameOverScreen getGameOverScreen() {

        return gameOver;

    }

    public GameWinnerScreen getGameWinnerScreen() {

        return gameWinner;
        
    }

    public QuizUI getQuizUI() {

        return quizUI;

    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                Main start = new Main();
                Settings settings = start.getSettings();
                Backstory backstory = start.getBackstory();
                QuizUI quizUI = start.getQuizUI();
                GameOverScreen gameOver = start.getGameOverScreen();
                GameWinnerScreen gameWinner = start.getGameWinnerScreen();

            }
        });
    }

}