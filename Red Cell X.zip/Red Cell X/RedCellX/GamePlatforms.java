package RedCellX;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.util.concurrent.atomic.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GamePlatforms extends JPanel implements ActionListener {

    private boolean gameStart;
    private JFrame frame;
    private int returnNum;
    private int greenPlatformHeight = 12;
    private Random random = new Random();
    private boolean screenResize;
    private boolean gravity;
    private int[] xValues = new int[10];
    private int[] yValues = new int[10];
    private int[] widthValues = new int[10];
    private int newFrameCentreX;
    private int newFrameCentreY;
    private int oldCentreX;
    private int oldCentreY;
    private int oldX;
    private int oldY;
    private int ballX;
    private int ballY;
    private int ballDiameter;
    private Rectangle ballBounds;
    private boolean[] hasGoldenCell = new boolean[10];
    private int cellY;
    private int goldenCellDiameter = 25;
    private boolean infoPause;
    private boolean platform;
    private int oldCellY = 0;
    private int hitY;
    private Rectangle goldenCellBounds;
    private final Object lock;
    private int distanceMoved;
    private boolean startDistanceMoved;
    private int goldenCellXValue;
    private JPanel panel;
    private Timer infoTimer = new Timer(10000, this);
    private JLabel infoLabel = new JLabel();
    private Info infoBank;
    private boolean alreadyCalled;

    public GamePlatforms(boolean gameStart, JFrame frame, Object lock, JPanel panel) { 

        /* Initialization of the instance variables of the RedBloodCellGame class passed as parameters*/
        this.gameStart = gameStart;
        this.frame = frame;
        this.lock = lock;
        this.panel = panel;

        panel.setLayout(new BorderLayout());

        int x = frame.getWidth();
        int y = frame.getHeight();
        Dimension dimension = new Dimension(x, y);
        panel.setPreferredSize(dimension);

        y = 100;
        dimension = new Dimension(x, y);
        infoLabel.setPreferredSize(dimension);
        infoLabel.setVisible(false);
        panel.add(infoLabel, BorderLayout.SOUTH);

        infoBank = new Info();

    }

    @Override
    public synchronized void actionPerformed(ActionEvent e) { 
        synchronized(lock) {
            if (e.getSource() == infoTimer) {

                infoLabel.setVisible(false);
                infoPause = false;
                alreadyCalled = false;
                gravity = true;
                infoTimer.stop();

            }
        }
    }

    public void setScreenResize(boolean screenResize) {
        
        /* Initialization of the screenResize for the platforms*/
        this.screenResize = screenResize;

    }

    public void setGravity(boolean gravity) {

        /* Initialization of the screenResize for the gravity*/
        this.gravity = gravity;

    }

    public int getPlatformTop() {

        return hitY;

    }

    public boolean checkCollision(int ballX, int ballY, int ballDiameter) {
        synchronized(lock) {

            AtomicBoolean collisionResult = new AtomicBoolean(false);
            AtomicInteger platformY = new AtomicInteger(0);

            PlatformCollisionThread collisionThread = new PlatformCollisionThread(platformY, collisionResult, ballX, ballY, ballDiameter, xValues, yValues, widthValues, greenPlatformHeight);
            collisionThread.start();

            // Wait for the thread to finish
            
            try {
                collisionThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Retrieve the result from the AtomicBoolean using get()
            boolean collisionDetected = collisionResult.get();
            hitY = (platformY.get())-20;
            return collisionDetected;
        }
    }

    public boolean checkGoldenCellCollision(int ballX, int ballY, int ballDiameter, boolean alreadyColliding) {
        synchronized(lock) {

            startDistanceMoved = false;
            distanceMoved = 0;
            if (goldenCellBounds!=null && oldCellY != (cellY-distanceMoved)) {

                AtomicBoolean collisionResult = new AtomicBoolean(false);
                GoldenCellCollisionThread collisionThread = new GoldenCellCollisionThread(collisionResult, ballX, ballY, ballDiameter, goldenCellBounds);
                collisionThread.start();

                // Wait for the thread to finish
                try {
                    collisionThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Retrieve the result from the AtomicBoolean using get()
                boolean collisionDetected = collisionResult.get();
                if(collisionDetected == true) {
                    oldCellY = cellY;
                    startDistanceMoved = true;
                }

                return collisionDetected;
            }

            return false;
        }
    }

    public synchronized void setInfoPause() {
        synchronized(lock) {

            gravity = false;
            infoTimer.start();
            //alreadyCalled = false;
            infoPause = true;
            panel.repaint();

        }
    }

    private int randomX() {

        returnNum = random.nextInt(oldX-100);
        if(returnNum < 50) {
            
            returnNum += 30;

        }
        return returnNum;
    }

    private int randomY() {

        /*Method returns a random y-coordinate manipulated as such the platform fits the screen*/
        returnNum = random.nextInt(oldY-70);
        if (returnNum < 100) {

            returnNum += 50;

        }
        return returnNum;

    }

    private int randomWidth() {

        /*Method returns a random width for the platform manipulated as such to fit the screen, 
        and be reasonable to fit the ball*/

        returnNum = random.nextInt(11);
        if (returnNum < 4) {

            returnNum = 4;

        }
        returnNum *= 12;
        return returnNum;
    }

    public int randomGoldenCell () {

        return random.nextInt(10);

    }

    public int getGoldenCellXCoordinate() {

        return goldenCellXValue;

    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (gameStart) {

            /* Creation of the paltforms at the beginning of the game */
            oldX = frame.getWidth();
            oldY = frame.getHeight();

            int goldenCellPosition = randomGoldenCell();
            hasGoldenCell[goldenCellPosition] = true;

            for (int i = 0; i < 10; i++) {

                xValues[i] = randomX();
                yValues[i] = randomY();
                widthValues[i] = randomWidth();

                g.setColor(Color.GREEN);
                g.fillRect(xValues[i], yValues[i], widthValues[i], greenPlatformHeight);

                if (hasGoldenCell[i]) {
                    // Draw golden cells on platforms
                    goldenCellXValue = xValues[i];
                    g.setColor(Color.YELLOW);
                    cellY = yValues[i] - goldenCellDiameter; // Adjust the Y position
                    g.fillOval(xValues[i], cellY, goldenCellDiameter, goldenCellDiameter);
                }

            }

            gameStart = false;

        }

        if (startDistanceMoved) {
        
            distanceMoved++;

        }

        
        if (gravity) {
            
            /* Moving the platforms upwards to give the perception of a moving screen. 
            * Additionally, regenerating the platforms that leave the screen.*/
            
            for (int i = 0; i<10; i++) {

                if(yValues[i] > -1) {
                    
                    yValues[i] -= 1;

                } else {

                    yValues[i] += (frame.getHeight() - 200);
                    xValues[i] = randomX();
                    widthValues[i] = randomWidth();

                }

                g.setColor(Color.GREEN);
                g.fillRect(xValues[i],yValues[i], widthValues[i], greenPlatformHeight);
                
                if (hasGoldenCell[i]) {
                    // Redraw golden cells on platforms to account for gravity
                    goldenCellXValue = xValues[i];
                    g.setColor(Color.YELLOW);
                    cellY = yValues[i] - goldenCellDiameter; // Adjust the Y position
                    g.fillOval(xValues[i], cellY, goldenCellDiameter, goldenCellDiameter);
                    goldenCellBounds = new Rectangle(xValues[i], cellY, goldenCellDiameter, goldenCellDiameter);

                }

            }
        }

        if (infoPause) {

            if(!alreadyCalled) {
                // Start info timer

                for (int i = 0; i<10; i++) {

                    g.setColor(Color.GREEN);
                    g.fillRect(xValues[i],yValues[i], widthValues[i], greenPlatformHeight);
                    
                    if (hasGoldenCell[i]) {
                        // Redraw golden cells on platforms to account for gravity
                        g.setColor(Color.YELLOW);
                        cellY = yValues[i] - goldenCellDiameter; // Adjust the Y position
                        g.fillOval(xValues[i], cellY, goldenCellDiameter, goldenCellDiameter);
                    }

                }

                String temp = infoBank.readFile();

                infoLabel.setText("<html>" + temp.replaceAll("\n", "<br>") + "</html>");
                infoLabel.setBackground(new Color(173, 216, 230));
                infoLabel.setOpaque(true);
                infoLabel.setForeground(Color.BLACK);
                Font font = new Font("Arial", Font.PLAIN, 20);
                infoLabel.setFont(font);
                infoLabel.setHorizontalAlignment(SwingConstants.CENTER);
                infoLabel.setVisible(true);
                alreadyCalled = true;
            }
        }
        
        if (screenResize) {

            /* Resizing of the platforms as the screen is resized to fill up the space */
            
            newFrameCentreX = (frame.getWidth())/2;
            oldCentreX = oldX/2;

            newFrameCentreY = (frame.getHeight())/2;
            oldCentreY = oldY/2;
            
            for (int i = 0; i < 10; i++) {

                xValues[i] = (newFrameCentreX - (oldCentreX - xValues[i]));
                yValues[i] = (newFrameCentreY - (oldCentreY - yValues[i]));

                g.setColor(Color.GREEN);
                g.fillRect(xValues[i],yValues[i], widthValues[i], greenPlatformHeight);

            }

            oldX = frame.getWidth();
            oldY = frame.getHeight();

        } 

    }
}
