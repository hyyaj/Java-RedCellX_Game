package RedCellX;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.InputMismatchException;


public class QuizUI extends JPanel implements ActionListener {

    private JFrame frame = new JFrame();
    private JPanel gamePanel = new JPanel();
    private JPanel quizPanel = new JPanel();
    private ImageIcon ghostPic;
    private JLabel ghostLabel;
    private int x = 125;
    private int y;
    private int randomQuestion;
    private String filePath;
    private String readString;
    private String aOutput;
    private String bOutput;
    private String cOutput;
    private String dOutput;
    private int answerLine;
    private String choice;
    private ArrayList<String> solutions = new ArrayList<>();
    private String correctSolution;
    private JButton aButton = new JButton("");
    private JButton bButton = new JButton("");
    private JButton cButton = new JButton("");
    private JButton dButton = new JButton("");
    private Timer gameOverTimer;
    private Timer gameWinnerTimer;
    private Random random = new Random();
    private Image ghostImage;
    private JLabel question;
    private int currentQuestion = 0;
    private ArrayList<String> correctSolutions;
    private GameOverScreen gameOver;
    private GameWinnerScreen gameWinner;
    private JPanel titlePanel;
    private JPanel elementsPanel;
    private JPanel questionAPanel;
    private JPanel questionCPanel;

    public QuizUI() {

        quizPanel = new JPanel();
        filePath = "Solutions.txt";
        readSolutions();
        gameOverTimer = new Timer(2000, this);
        gameWinnerTimer = new Timer(2000, this);
        question = new JLabel();
        gameOver = new GameOverScreen(frame, gamePanel);
        gameWinner = new GameWinnerScreen(frame, gamePanel);
        quizPanel.add(question);

        aButton.addActionListener(e -> {

            choice = e.getActionCommand();
            if (choice.equals(correctSolutions.get(currentQuestion-1))) {
                
                correctChoice();
                        
            } else {
            
                wrongChoice();
                        
            }

        });
        
        bButton.addActionListener(e -> {

            choice = e.getActionCommand();
            if (choice.equals(correctSolutions.get(currentQuestion-1))) {
                
                correctChoice();
                        
            } else {
            
                wrongChoice();
                        
            }

        });

        cButton.addActionListener(e -> {

            choice = e.getActionCommand();
            if (choice.equals(correctSolutions.get(currentQuestion-1))) {
                
                correctChoice();
                        
            } else {
            
                wrongChoice();
                        
            }

        });

        dButton.addActionListener(e -> {

            choice = e.getActionCommand();
            if (choice.equals(correctSolutions.get(currentQuestion-1))) {
                
                correctChoice();
                        
            } else {
            
                wrongChoice();
                        
            }

        });

    }

    public void readSolutions() {
        
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String line;
            // Read each line from the file and append it to the StringBuilder
            while ((line = br.readLine()) != null) {
                
                solutions.add(line);

            }
            
        } catch (InputMismatchException e) {

            System.out.println("Caught TypeMismatchException: " + e.getMessage());
            // Handle TypeMismatchException (NumberFormatException) here

        } catch (IOException e) {

            System.out.println("Caught IOException: " + e.getMessage());
            // Handle IOException here

        }
        
    }

    public void openPanel() {

        ghostLabel = new JLabel();

        Dimension di = new Dimension(frame.getWidth()/5, 2*(frame.getHeight()/3));
        
        questionAPanel = new JPanel();
        questionAPanel.setPreferredSize(di);
        questionAPanel.setLayout(new BoxLayout(questionAPanel, BoxLayout.Y_AXIS));

        questionCPanel = new JPanel();
        questionCPanel.setPreferredSize(di);
        questionCPanel.setLayout(new BoxLayout(questionCPanel, BoxLayout.Y_AXIS));

        titlePanel = new JPanel();
        Dimension dimension = new Dimension(frame.getWidth(), frame.getHeight()/3); // Width x Height
        titlePanel.setPreferredSize(dimension);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.X_AXIS));

        elementsPanel = new JPanel();
        dimension = new Dimension(frame.getWidth(), 2*(frame.getHeight()/3));
        elementsPanel.setLayout(new BoxLayout(elementsPanel, BoxLayout.X_AXIS));

        Dimension preferredSize = new Dimension(frame.getWidth(), frame.getHeight()); // Width x Height
        quizPanel.setPreferredSize(preferredSize);
        quizPanel.setLayout(new BoxLayout(quizPanel, BoxLayout.Y_AXIS));

        fillPanel();
        
        frame.add(quizPanel);
        frame.revalidate();
        repaint();
        correctSolutions = new ArrayList<>();
        currentQuestion = 0;
        showQuestions();

    }
    
    public void fillPanel() {

        quizPanel.add(Box.createHorizontalGlue());
        quizPanel.add(Box.createVerticalGlue());
        quizPanel.add(Box.createRigidArea(new Dimension(10, 10)));

        titlePanel.add(Box.createHorizontalGlue());
        titlePanel.add(Box.createVerticalGlue());
        titlePanel.add(Box.createRigidArea(new Dimension(10, 10)));

        elementsPanel.add(Box.createHorizontalGlue());
        elementsPanel.add(Box.createVerticalGlue());
        elementsPanel.add(Box.createRigidArea(new Dimension(10, 10)));

        questionAPanel.add(Box.createHorizontalGlue());
        questionAPanel.add(Box.createVerticalGlue());
        questionAPanel.add(Box.createRigidArea(new Dimension(10, 10)));

        questionCPanel.add(Box.createHorizontalGlue());
        questionCPanel.add(Box.createVerticalGlue());
        questionCPanel.add(Box.createRigidArea(new Dimension(10, 10)));

        quizPanel.add(titlePanel);
        quizPanel.add(elementsPanel);

        titlePanel.add(question);

        aButton.setFont(aButton.getFont().deriveFont(Font.PLAIN, 20));
        bButton.setFont(bButton.getFont().deriveFont(Font.PLAIN, 20));
        cButton.setFont(cButton.getFont().deriveFont(Font.PLAIN, 20));
        dButton.setFont(dButton.getFont().deriveFont(Font.PLAIN, 20));


        questionAPanel.add(aButton);
        questionAPanel.add(Box.createVerticalStrut(frame.getHeight()/4));
        questionAPanel.add(cButton);
        questionAPanel.add(Box.createVerticalStrut(frame.getHeight()/4));

        questionCPanel.add(bButton);
        questionCPanel.add(Box.createVerticalStrut(frame.getHeight()/4));
        questionCPanel.add(dButton);
        questionCPanel.add(Box.createVerticalStrut(frame.getHeight()/4));

        elementsPanel.add(questionAPanel);
        resizeGhost();
        elementsPanel.add(ghostLabel);
        elementsPanel.add(questionCPanel);

    }

    public void resizeGhost() {

        filePath = "ghost.png";
        try {

            File inputFile = new File(filePath);
            BufferedImage originalImage = ImageIO.read(inputFile);

            // Create a new BufferedImage with the specified width and height
            int a = (int) frame.getWidth()/5;
            int b = (int) frame.getHeight()/3;
            Image resizedImage = originalImage.getScaledInstance(a - 50, b, Image.SCALE_SMOOTH);
            ghostPic = new ImageIcon(resizedImage);
            ghostLabel.setIcon(ghostPic);
            Dimension dimension = new Dimension(a,b);
            ghostLabel.setPreferredSize(dimension);

        } catch (IOException e) {

            e.printStackTrace();
            // Handle the exception according to your requirements

        }

    }

    public void showQuestions() {

        //show Questions

        randomQuestion = random.nextInt(20);
        randomQuestion++;
        filePath = "Questions.txt";
        readString = readFile(filePath, randomQuestion);
        question.setText("<html>" + readString.replaceAll("\n", "<br>") + "</html>");
        question.setBackground(new Color(173, 216, 230));
        question.setOpaque(true);
        question.setForeground(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 24);
        question.setFont(font);
        int a = (frame.getWidth());
        int b = frame.getHeight()/3;
        Dimension dim = new Dimension(a,b);
        question.setPreferredSize(dim);
        question.setHorizontalAlignment(SwingConstants.CENTER);

        currentQuestion++;
        if(currentQuestion < 4) {

            question.setVisible(true);
            correctSolution = solutions.get((randomQuestion-1));
            correctSolutions.add(correctSolution);
            frame.revalidate();        
            showOptions();

        } else if(currentQuestion > 4) {

            gameWinnerTimer.start();

        }
        
    }

    public String readFile(String filePath, int randomQuestion) {
    
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String line;
            int currentLine = 1;

            // Read each line from the file and append it to the StringBuilder
            while ((line = br.readLine()) != null) {

                if (currentLine == randomQuestion) {

                    return line;

                }

                currentLine++;

            }

            return "Line number out of range.";

        } catch (IOException e) {

            // Handle file reading errors
            return "An error occurred: " + e.getMessage();

        }
    
    }

    public void showOptions() {

        filePath = "Options.txt";

        //a
        answerLine = (1 + (4*(randomQuestion-1)));
        aOutput = readFile(filePath, answerLine);
        displayA();

        //b
        answerLine = (2 + (4*(randomQuestion-1)));
        bOutput = readFile(filePath, answerLine);
        displayB();

        //c
        answerLine = (3 + (4*(randomQuestion-1)));
        cOutput = readFile(filePath, answerLine);        
        displayC();

        //d
        answerLine = (4 + (4*(randomQuestion-1)));
        dOutput = readFile(filePath, answerLine);
        displayD();

    }

    private void setTextFit(JButton button, String text) {
        Font originalFont = (Font)button.getClientProperty("originalfont"); // Get the original Font from client properties
        if (originalFont == null) { // First time we call it: add it

            originalFont = button.getFont();
            button.putClientProperty("originalfont", originalFont);

        }
    
        int stringWidth = button.getFontMetrics(originalFont).stringWidth(text);
        int componentWidth = frame.getWidth()/3;
    
        if (stringWidth > componentWidth) { // Resize only if needed
            
            // Find out how much the font can shrink in width.
            double widthRatio = (double)componentWidth / (double)stringWidth;
    
            int newFontSize = (int)Math.floor(originalFont.getSize() * widthRatio); // Keep the minimum size
    
            // Set the label's font size to the newly determined size.
            button.setFont(new Font(originalFont.getName(), originalFont.getStyle(), newFontSize));

        } else {

            button.setFont(originalFont); // Text fits, do not change font size
            button.setText(text);

        }
    }

    public void displayA() {

        setTextFit(aButton, aOutput);
        aButton.setBackground(Color.BLUE); 
        aButton.setForeground(Color.WHITE);
        frame.revalidate();
        aButton.addActionListener(this);

    }

    public void displayB() {

        setTextFit(bButton, bOutput);
        bButton.setBackground(Color.BLUE); 
        bButton.setForeground(Color.WHITE);
        frame.revalidate();
        bButton.addActionListener(this);

    }

    public void displayC() {

        setTextFit(cButton, cOutput);
        cButton.setBackground(Color.BLUE);
        cButton.setForeground(Color.WHITE); 
        frame.revalidate();
        cButton.addActionListener(this);

    }

    public void displayD() {

        setTextFit(dButton, dOutput);
        dButton.setBackground(Color.BLUE); 
        dButton.setForeground(Color.WHITE);
        frame.revalidate();
        dButton.addActionListener(this);

    }

    public void closePanel(JFrame frame, JPanel gamePanel) {

        this.frame = frame;
        this.gamePanel = gamePanel;
        frame.remove(gamePanel);
        frame.revalidate();
        repaint();
        openPanel();

    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == gameOverTimer) {

            gameOverTimer.stop();
            gameOver.closePanel(frame, quizPanel);

        }

        if (e.getSource() == gameWinnerTimer) {

            gameWinnerTimer.stop();
            gameWinner.closePanel(frame, quizPanel);

        }

    }

    public void wrongChoice() {

        if (!aOutput.equals(correctSolution)) {
            
            aButton.setBackground(Color.RED); 

        }
        
        if (!bOutput.equals(correctSolution)) {
            
            bButton.setBackground(Color.RED); 

        }
        
        if (!cOutput.equals(correctSolution)) {
            
            cButton.setBackground(Color.RED); 

        }
        
        if (!dOutput.equals(correctSolution)) {
            
            dButton.setBackground(Color.RED); 

        }

        if (aOutput.equals(correctSolution)) {
            
            aButton.setBackground(Color.GREEN); 

        } else if (bOutput.equals(correctSolution)) {
            
            bButton.setBackground(Color.GREEN); 

        } else if (cOutput.equals(correctSolution)) {
            
            cButton.setBackground(Color.GREEN); 

        } else if (dOutput.equals(correctSolution)) {
            
            dButton.setBackground(Color.GREEN); 

        }

        gameOverTimer.start();

    }

    public void correctChoice() {

        if (aOutput.equals(correctSolution)) {
            
            aButton.setBackground(Color.GREEN); 

        } else if (bOutput.equals(correctSolution)) {
            
            bButton.setBackground(Color.GREEN); 

        } else if (cOutput.equals(correctSolution)) {
            
            cButton.setBackground(Color.GREEN); 

        } else if (dOutput.equals(correctSolution)) {
            
            dButton.setBackground(Color.GREEN); 

        }


        if (currentQuestion < 4) {
    
            if (currentQuestion >= 3) {

                gameWinnerTimer.start();

            } else {

                showQuestions();

            }
        }

    }
}