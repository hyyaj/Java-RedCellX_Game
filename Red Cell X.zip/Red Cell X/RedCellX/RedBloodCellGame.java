package RedCellX;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RedBloodCellGame extends JPanel implements ActionListener {
    
    private JFrame frame;
    private JPanel gamePanel;
    private int cellX;
    private int cellY; 
    private boolean gameStart = false;
    private int distanceAway;
    private Timer timer = new Timer(10, this);
    private GamePlatforms gamePlatforms;
    private QuizUI quizUI;
    private GameOverScreen gameOverScreen;
    private boolean gravity;
    private boolean gameRunning;
    private boolean screenResize;
    private boolean keyPressed;
    private int cellDiameter = 4;
    private int goldenCellsHit = 0;
    private boolean goldenCellHit;
    private boolean infoPause;
    private Timer goldenCellsTimer;
    private boolean alreadyColliding = false;
    private int numThreads = Runtime.getRuntime().availableProcessors(); // Number of CPU cores
    private ExecutorService executor1 = Executors.newFixedThreadPool(numThreads);
    private ExecutorService executor2 = Executors.newFixedThreadPool(numThreads);
    private JPanel oldPanel;
    private PlatformCollisionThread platformCollisionThread;
    private GoldenCellCollisionThread goldenCellCollisionThread;
    private int goldenCellXValue;
    private int oldgoldenCellXValue;

    private ExecutorService collisionExecutor = Executors.newFixedThreadPool(2);
    private Future<Boolean> collisionDetectionFuture;
    private final Object lock = new Object();

    @Override
    public synchronized void actionPerformed(ActionEvent e) { 
        if (gameRunning) {
            /*Tell the platforms in the GamePlatforms class that gravity is now true*/
            if (collisionDetectionFuture == null || collisionDetectionFuture.isDone()) {
            collisionDetectionFuture = collisionExecutor.submit(() -> {
                synchronized (lock) {

                    boolean collisionDetected = gamePlatforms.checkCollision(cellX, cellY, cellDiameter);

                    if (collisionDetected) {

                        cellY = gamePlatforms.getPlatformTop(); // Set Y position just above the platform
                        gamePanel.repaint();
                        gravity = false; // Stop gravity when landed on a platform

                    } else if (!infoPause) {

                        gravity = true; // Resume gravity when not on a platform

                    }

                    return collisionDetected;

                    }
                });
            }
            // Check if the collision detection thread has completed
            if (collisionDetectionFuture.isDone()) {
                try {

                    boolean collisionDetected = collisionDetectionFuture.get();
                    if (collisionDetected) {

                        cellY = gamePlatforms.getPlatformTop(); // Set Y position just above the platform
                        gamePanel.repaint();
                        gravity = false; // Stop gravity when landed on a platform

                    } else if (!infoPause) {

                        gravity = true; // Resume gravity when not on a platform

                    }

                } catch (InterruptedException | ExecutionException ex) {
                    ex.printStackTrace();
                }
            }
            
            synchronized (lock) {
                if (gravity) {

                    cellY += 1;
                    gamePlatforms.setGravity(gravity);
                    gamePanel.repaint();

                }
            }

            if (!executor2.isShutdown()) {
                Future<Boolean> collisionDetectionFuture = executor2.submit(() -> {
                    synchronized (lock) {
                        
                        boolean collisionDetected = (gamePlatforms.checkGoldenCellCollision(cellX, cellY, cellDiameter, alreadyColliding));
                        goldenCellXValue = gamePlatforms.getGoldenCellXCoordinate();

                        if (goldenCellXValue == oldgoldenCellXValue) {

                            alreadyColliding = true;

                        } else {

                            alreadyColliding = false;
                        }

                        return collisionDetected;
                    }
                });
            
                try {
                    boolean collisionDetected = collisionDetectionFuture.get();
                    if (collisionDetected) {

                        if(!alreadyColliding) {

                            infoPause = true;
                            alreadyColliding = true;
                            goldenCellHit = true;
                            goldenCellsHit += 1;
                            oldgoldenCellXValue = goldenCellXValue;
                            gravity = false;
                            gamePlatforms.setInfoPause();
                             
                            if (goldenCellsHit == 3) {
                                goldenCellsTimer.start();
                            }

                        } else {

                            infoPause = false;
                        }
                    } else {

                        infoPause = false;

                    }

                } catch (InterruptedException | ExecutionException g) {

                    g.printStackTrace();

                }
            }
                 
        

            if (cellX < 0 || cellX > (frame.getWidth()) || cellY < 0 || cellY>(frame.getHeight())) {

                gameRunning = false;
                gameOverScreen.closePanel(frame, gamePanel);

            }
        }

        gamePanel.repaint();

        if (e.getSource() == goldenCellsTimer) {

            executor1.shutdown();
                        
            try {
                executor1.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException h) {
                h.printStackTrace();
            }
            
            executor2.shutdown();
                        
            try {
                executor2.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException h) {
                h.printStackTrace();
            }

            goldenCellsTimer.stop();
            if(gameRunning) {

                quizUI.closePanel(frame, gamePanel);

            }

        }

    }
    

    public RedBloodCellGame(JFrame frame, JPanel oldPanel) {

        goldenCellsTimer = new Timer(20000, this);
        gameStart = true;
    
        this.frame = frame;
        this.oldPanel = oldPanel;

        gamePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                gamePanel.setFocusable(true);
                gamePanel.requestFocus();

                if (gameStart) {

                    g.setColor(Color.RED);
                    g.fillOval(cellX, cellY, 20, 20);
                    gamePlatforms.paintComponent(g);
                    gameStart = false;

                }
                
                if (screenResize) {

                    g.setColor(Color.RED);
                    g.fillOval(cellX, cellY, 20, 20);
                    gamePlatforms.paintComponent(g);

                } 
                
                if (keyPressed) {

                    g.setColor(Color.RED);
                    g.fillOval(cellX, cellY, 20, 20);
                    keyPressed = false;

                } 
                
                if (gameRunning) {
                    
                    g.setColor(Color.RED);
                    g.fillOval(cellX, cellY, 20, 20);
                    gamePlatforms.paintComponent(g);

                    g.setColor(Color.BLACK);
                    g.setFont(new Font("Arial", Font.PLAIN, 20));
                    g.drawString("Golden Cells: " + goldenCellsHit, (frame.getWidth() - 250), 30);

                }
            }
        };

        gamePanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
            
                int keyCode = e.getKeyCode();
                if (gameRunning) {

                    if (keyCode == KeyEvent.VK_LEFT) {

                        cellX -= 10;
                        distanceAway -= 10;
                        keyPressed = true;
                        gamePanel.repaint();

                    } else if (keyCode == KeyEvent.VK_RIGHT) {

                        cellX += 10;
                        distanceAway += 10;
                        keyPressed = true;
                        gamePanel.repaint();

                    }

                }
            }
        });

        gamePanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {

                screenResize = true;
                cellX = (frame.getWidth()/2) + distanceAway;
                gamePlatforms.setScreenResize(screenResize);
                gamePanel.repaint();

            }

        });
                
        gamePlatforms = new GamePlatforms(gameStart, frame, lock, gamePanel);
        quizUI = new QuizUI();
        gameOverScreen = new GameOverScreen(frame, gamePanel);
        platformCollisionThread = new PlatformCollisionThread(lock);
        goldenCellCollisionThread = new GoldenCellCollisionThread(lock);

    }

    public void startGame(JPanel oldPanel) {
        this.oldPanel = oldPanel;
        frame.getContentPane().removeAll();
        closePanel();
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();

        cellX = frame.getWidth()/2; // Initial X position
        cellY = 10;  // Initial Y position 
        gameRunning = true;

        frame.setVisible(true);
        timer.start();
        gravity = true;

    }
    

    private void closePanel() {

        frame.remove(oldPanel);
        frame.revalidate();

    }

    public GamePlatforms getGamePlatforms() {
        
        return gamePlatforms;

    }

    public QuizUI getQuizUI() {

        return quizUI;

    }

    public GameOverScreen getGameOverScreen() {

        return gameOverScreen;

    }

}
